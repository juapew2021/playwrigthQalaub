export default interface PageElement {
    selector: string,
    find: string,
}